#!/bin/bash

# loads BOSH context
source bosh-alias.sh

# set basic cloud config
./update-cloud-config.sh

# upload stemcell required by ZooKeeper
bosh upload-stemcell https://bosh.io/d/stemcells/bosh-aws-xen-hvm-ubuntu-trusty-go_agent?v=3586.100

# get ZooKeeper manifest
wget https://raw.githubusercontent.com/fabianlee/bosh-director-on-aws/master/zookeeper.yml -O zookeeper.yml
# deploy 3 cluster instance of Apache zookeeper
bosh -n -d zookeeper deploy -v zookeeper_instances=3 zookeeper.yml

# show available deployments (zookeeper should exist now)
bosh deployments

# show instantiated VM (should be 3)
bosh -d zookeeper vms
