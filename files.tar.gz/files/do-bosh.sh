#!/bin/bash

state="--state=state.json"
if [ -z $1 ]; then
  action="int"
else
  action=$1
fi

# if doing interpolate, then state is invalid option
if [ "$action" == "int" ]; then
  state=""
fi

echo Performing $action
bosh -n $action \
    $state \
    bosh-deployment/bosh.yml \
    --vars-store=creds.yml \
    -o bosh-deployment/aws/cpi.yml \
    -o set-director-passwd.yml \
    -v director_name=bosh \
    -v internal_cidr=10.0.0.0/24 \
    -v internal_gw=10.0.0.1 \
    -v internal_ip=10.0.0.6 \
    -v access_key_id=AKIAXTQM5CFYTH53BL7N \
    -v secret_access_key=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 \
    -v region=us-east-1 \
    -v az=us-east-1a \
    -v default_key_name=bosh \
    -v default_security_groups=[bosh-private-bosh] \
    --var-file private_key=bosh.pem \
    -v subnet_id=enteryoursubnetidhere \
    --vars-file vars.yml \
    -o bosh-deployment/jumpbox-user.yml \
