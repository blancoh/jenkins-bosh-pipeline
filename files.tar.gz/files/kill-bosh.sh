source bosh-alias.sh

# delete ZooKeeper cluster
bosh -n -d zookeeper delete-deployment

# should not show ZooKeeper anymore
bosh deployments

# delete stemcell ZooKeeper required
bosh stemcells
bosh delete-stemcell bosh-warden-boshlite-ubuntu-trusty-go_agent/3586.100

# delete BOSH Director
./do-bosh.sh delete-env
