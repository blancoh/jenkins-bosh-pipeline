#!/bin/bash

# run 'create-env'
./do-bosh.sh create-env

# loads BOSH context
source bosh-alias.sh

# show current env
bosh env

# set basic cloud config
./update-cloud-config.sh

# show deployments (should be empty)
bosh deployments

# show vms (should be empty)
bosh vms
