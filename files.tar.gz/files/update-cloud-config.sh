bosh -n update-cloud-config bosh-deployment/aws/cloud-config.yml -v az=us-east-1a -v internal_cidr=10.0.0.0/24 -v internal_gw=10.0.0.1 -v subnet_id=enteryoursubnetidhere 
